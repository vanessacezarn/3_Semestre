package exercicio1;

public class Figura {
	protected String cor;
	protected String preenchido;
	
	
}
