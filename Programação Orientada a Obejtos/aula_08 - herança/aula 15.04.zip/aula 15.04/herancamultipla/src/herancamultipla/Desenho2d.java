package herancamultipla;

public class Desenho2d extends Desenho {
	protected int largura;
	protected int altura;
	
	public Desenho2d(int largura, int altura) {
		super();
		this.largura = largura;
		this.altura = altura;
	}
	
	
	

}
