package herancamultipla;

public class Quadrado extends Desenho2d {
	protected String descricao;


	public Quadrado(int largura, int altura,String descricao) {
		super(largura, altura);
		this.descricao=descricao;
	}
	public void exibeDados() {
		System.out.println("nome autor: "+this.nomeAutor);
		System.out.println("largura: "+this.largura);
		System.out.println("altura: "+this.altura);
		System.out.println("descricao: "+this.descricao);

		
	}

}
