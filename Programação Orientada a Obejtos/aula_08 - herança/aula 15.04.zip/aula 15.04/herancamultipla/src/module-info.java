/**
 * 
 */
/**
 * 
 */
module herancamultipla {
}