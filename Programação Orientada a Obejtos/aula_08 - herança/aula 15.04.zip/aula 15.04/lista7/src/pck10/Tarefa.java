package pck10;

public class Tarefa {
	private String descricao;
	private boolean concluida;
	
	public Tarefa(String descricao) {
		this.descricao = descricao;
		this.concluida = false;
	}
	
	public void concluirTarefa() {
		this.concluida = true;
		System.out.println("Mensagem do sistema: tarefa concluida com sucesso !!");
	}
	
	
	public void exibirTarefa() {
		System.out.print("Tarefa: "+this.descricao);
		if(this.concluida) {
			System.out.println(" Concluida");
		}else {
			System.out.println(" Não concluida");
		}
	}
	
	
	
	
}
