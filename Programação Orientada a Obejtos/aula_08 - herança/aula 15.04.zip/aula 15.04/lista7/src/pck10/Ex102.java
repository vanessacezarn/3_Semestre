package pck10;

import java.util.Scanner;

public class Ex102 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);
		//int[] vetor = new int[3]; EXPLICAÇÃO DE COMO CRIAR O VETR
		
		String descricao;
		Tarefa[] tarefas = new Tarefa[3];
		
		for(int i=0 ; i<3; i++) {
			System.out.print("Digite a descrição da tarefa "+i+" : ");
			descricao=teclado.nextLine();
			tarefas[i] = new Tarefa(descricao); 
			}
		
		tarefas[1].concluirTarefa();
		
		System.out.println("\n");
		for( int i=0 ; i<3; i++) {
			tarefas[i].exibirTarefa();
		}
		
		teclado.close();
		
		
	}

}
