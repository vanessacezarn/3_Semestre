package aula08;

public class Onibus extends Carro {
	//CLASSE ONIBUS EXTENDE CARRO
	// ESTA CLASSE ONIBUS HERDA TUDO QUE TEM NA CLASSE Carro
	protected String modelo;

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	
}
