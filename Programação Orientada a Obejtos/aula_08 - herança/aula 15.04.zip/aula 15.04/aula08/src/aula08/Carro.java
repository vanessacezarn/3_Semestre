package aula08;

public class Carro {
	
	protected String nome;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public void exibeMsg() {
		System.out.println("Estou na classe CARRO \no nome do carro é : "+nome);
	}
	

}
