package aula08;

public class Principal {

	public static void main(String[] args) {
		
		Carro c = new Carro();
		c.setNome("Fusca");
		c.exibeMsg();
		
		Onibus o = new Onibus();
		o.setNome("Expresso Medianeira");
		o.setModelo("OF-0984");
		o.exibeMsg();
		System.out.println("o modelo do onibus é : "+ o.getModelo());
			
	}

}
