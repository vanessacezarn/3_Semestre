package jogo_rapido1;

public class Animal {
	protected String nome;
	protected String som;
	protected int idade;
	
	public void exibir() {
		System.out.println("nome: "+nome);
		System.out.println("idade:  "+idade);
		
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSom() {
		return som;
	}

	public void setSom(String som) {
		this.som = som;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}
	
	
	
}
