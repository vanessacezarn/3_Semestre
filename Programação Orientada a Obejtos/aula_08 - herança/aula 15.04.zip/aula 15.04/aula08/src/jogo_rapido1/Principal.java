package jogo_rapido1;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cachorro c = new Cachorro();
		c.setNome("Tobi");
		c.setIdade(5);
		c.setSom("AUAU");
		c.setRaca("viralata");
		c.exibir();
		System.out.println("raça :  "+c.raca);
		c.latir();
	}

}
