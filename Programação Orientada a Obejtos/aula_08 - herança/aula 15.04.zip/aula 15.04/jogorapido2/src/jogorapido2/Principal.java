package jogorapido2;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pessoa p= new Pessoa("Vanessa ",22);
		p.exibeDados();
		
		System.out.println("\nPessoa Juridica");
		PessoaJuridica pj = new PessoaJuridica("Luiza",20,"123459");
		pj.exibeDados();
		System.out.println("cnpj: "+pj.cnpj);
		pj.setSocio ("Eric");
		System.out.println("socio: "+pj.socio);
		
	
		

	}

}
