package jogorapido2;

public class PessoaJuridica extends Pessoa{

	protected String cnpj;
	protected String socio;
	protected String dtAbertura;
	
	public PessoaJuridica(String nome, int idade,String cnpj ) {
		super(nome, idade);
		this.cnpj=cnpj;
		//pode instanciar os atributos dentro desse construtor
		// CLASSE PESSOA ("PAI") TEM UM CONSTRUTOR, LOGO A CLASSE PESSOA JURIDICA TEM QUE TER UM CONSTRUTOR POR CAUSA DA HERANÇA
		// SUPER() --> SIGNIFICA QUE QUANDO INSTANCIA PESSOAJURIDICA, PRECISO CHAMAR  O CONSTRUTOR DA SUPERCLASSE
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getSocio() {
		return socio;
	}

	public void setSocio(String socio) {
		this.socio = socio;
	}

	public String getDtAbertura() {
		return dtAbertura;
	}

	public void setDtAbertura(String dtAbertura) {
		this.dtAbertura = dtAbertura;
	}





}
