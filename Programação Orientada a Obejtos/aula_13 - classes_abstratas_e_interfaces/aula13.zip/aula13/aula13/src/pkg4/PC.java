package pkg4;

public interface PC {
	public void verificaEmail();
	

}
