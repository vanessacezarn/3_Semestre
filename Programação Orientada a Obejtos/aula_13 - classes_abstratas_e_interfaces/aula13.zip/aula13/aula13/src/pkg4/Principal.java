package pkg4;

public class Principal {

	public static void main(String[] args) {
		Smartphone s = new Smartphone("555","@gmail");
		s.verificaEmail();
		s.realizaChamada();
		
	}

}
