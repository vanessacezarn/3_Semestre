package pkg4;

public interface Celular {
	public void realizaChamada();

}
