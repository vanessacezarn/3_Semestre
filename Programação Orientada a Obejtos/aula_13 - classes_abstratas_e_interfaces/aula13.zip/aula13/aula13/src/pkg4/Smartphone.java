package pkg4;

public class Smartphone implements Celular,PC{
	public String tel;
	public String email;
	
	public Smartphone(String tel, String email) {
		super();
		this.tel = tel;
		this.email = email;
	}

	@Override
	public void verificaEmail() {
		System.out.println("verificando emails: "+email);
	}

	@Override
	public void realizaChamada() {
		System.out.println("realizando chamadas: "+tel);
		
	}

}
