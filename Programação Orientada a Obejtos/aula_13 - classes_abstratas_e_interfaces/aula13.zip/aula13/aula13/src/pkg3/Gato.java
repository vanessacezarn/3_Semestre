package pkg3;

public class Gato implements Animal {
	public String nome;
	public int idade;
	
	
	public Gato(String nome, int idade) {
		super();
		this.nome = nome;
		this.idade = idade;
	}

	@Override
	public void emitirSom() {
		System.out.println("MIAU ");
	}

	@Override
	public void exibiDados() {
		System.out.println("GATO: ");
		System.out.println("Nome:: "+nome);		
		System.out.println("Idade: "+idade);		
	}

}
