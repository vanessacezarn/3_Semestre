package pkg3;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal c = new Cachorro("TOBI",5);
		c.exibiDados();
		c.emitirSom();
		// COMO ESTA SENDO USADO UM METODO DA CLASSE CACHORRO TEM QUE IMPLENTAR CACHORRO E NÃO ANIMAL
		Cachorro cc = new Cachorro("a",8);
		cc.exibiDados();
		cc.emitirSom();
		cc.cuidarPatio();
		
	
		
		Animal g = new Gato("lala",3);
		g.exibiDados();
		g.emitirSom();

		
		
	}

}
