package pkg3;

public interface Animal {
	 void emitirSom();
	 void exibiDados();
}
