package pkg3;

public class Cachorro implements Animal {
	public String nome;
	public int idade;

	
	public Cachorro(String nome, int idade) {
		super();
		this.nome = nome;
		this.idade = idade;
	}

	@Override
	public void emitirSom() {
		System.out.println("AU AU");
	}
	
	public void cuidarPatio() {
		System.out.println("o cachorro está cuidando do patio");
	}

	@Override
	public void exibiDados() {
		System.out.println("CACHORRO: ");
		System.out.println("Nome:: "+nome);		
		System.out.println("Idade: "+idade);
	}


}
