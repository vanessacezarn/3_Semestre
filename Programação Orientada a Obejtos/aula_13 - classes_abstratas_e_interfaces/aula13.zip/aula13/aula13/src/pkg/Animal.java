package pkg;

abstract class Animal {
	// PELO ENCAPSULAMENTO SEMPRE VAI SER PUBLICO
	// public abstract class TAMBÉM PODER SER USADO
	public String especie;
	public int idade;
	
	public void exibeDados() {
		System.out.println("Espécie: "+especie);
		System.out.println("Idade: "+idade);

	}
	abstract void emitirSom();
	
	

}
