package pkg;

public class Principal {

	public static void main(String[] args) {
		Cachorro c = new Cachorro();
		c.especie = "cachorro";
		c.idade = 5;
		c.raca = "caramelo";
		c.exibeDados();
		c.cuidarPatio();
		c.emitirSom();
	}

}
