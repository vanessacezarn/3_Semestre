package pkg;

public class Cachorro extends Animal {
	// OBRIGATORIAMENTE A CLASSE QUE EXTENDER DE ANIMAL TEM QUE IMPLEMENTAR OS MÉTODOS DA CLASSE ABSTRATA
	public String raca;
	
	@Override
	void emitirSom() {
		System.out.println("Au Au Au");
	}
	
	public void cuidarPatio() {
		System.out.println("o cachorro está cuidando do pátio");
	}

	@Override
	public void exibeDados() {
		//super.exibeDados(); -> PELO CTRL+SHIFT+S
		System.out.println("Espécie: "+especie);
		System.out.println("Idade: "+idade);
		System.out.println("raça: "+raca);
	}
	
	
	
	

}
