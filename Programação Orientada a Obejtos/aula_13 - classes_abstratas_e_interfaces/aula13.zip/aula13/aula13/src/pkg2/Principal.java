package pkg2;

public class Principal {

	public static void main(String[] args) {
		System.out.println("RETANGULO");
		Retangulo r = new Retangulo(5,2.2);
		double areaR = r.area();
		double perimetroR = r.perimetro();
		System.out.println("area = "+areaR+" perimetro = "+perimetroR);
		
		System.out.println("CIRCULO");
		Circulo c = new Circulo(2);
		double areaC = c.area();
		double perimetroC = c.perimetro();
		System.out.println("area = "+areaC+" perimetro = "+perimetroC);

	}

}
