package pkg2;

public class Circulo extends Forma{
	private double raio;
	double pi = 3.14159;

	
	public Circulo(double raio) {
		this.raio = raio;
	}

	@Override
	public double area() {
		// TODO Auto-generated method stub
		return Math.PI*raio*raio;
	}

	@Override
	public double perimetro() {
		// TODO Auto-generated method stub
		return 2*Math.PI*raio;
	}
	

}
