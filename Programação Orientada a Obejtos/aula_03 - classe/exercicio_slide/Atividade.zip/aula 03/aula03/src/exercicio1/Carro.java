package exercicio1;

public class Carro {
	public String marca;
	public String modelo;
	public int anoFabricacao;

}
