package exercicio07;

public class NotificacaoApp extends Notificacao {
	public void enviar() {
		System.out.println("\nNotificação via App!!!");
		System.out.println(texto);
		
	}
}
