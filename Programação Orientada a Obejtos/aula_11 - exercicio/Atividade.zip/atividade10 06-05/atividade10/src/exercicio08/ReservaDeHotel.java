package exercicio08;

public class ReservaDeHotel extends Reserva{
	public void adicionarReserva() {
			System.out.println("Reserva de HOTEL feita para "+nome+" na data de "+data);		
		
		
	}
	public void cancelarReserva() {
		System.out.println("Cancelamento:Tratando de políticas de cancelamento especificas de Hotel");

	}

}