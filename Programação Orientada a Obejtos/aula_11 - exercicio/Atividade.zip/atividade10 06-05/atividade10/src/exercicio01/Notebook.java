package exercicio01;



public class Notebook extends Computador{
	

	public Notebook(String marca) {
		super(marca);
	}
	
	public void exibeMarca() {
		System.out.println("marca: "+marca);
	}
	
	

}