//8) Crie uma classe Usuario com os atributos:nomeUsuario (String),senha (String),logado (boolean, inicialmente false)
//Implemente:Um método login(String usuario, String senha) que valida os dados e muda o valor de logado para true se estiver correto
//Um método logout() que define logado como false
//Um método exibirStatus() que mostra se o usuário está logado ou não
//na Main:Crie um usuário com nome e senha definidos no código
//Peça que o usuário digite os dados via teclado para fazer login
//Mostre se o login foi bem-sucedido e permita o logout


package exercicio08;

import java.util.Scanner;

public class Ex8 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);

		Usuario u = new Usuario();
		u.nomeUsuario = "Vanessa";
		u.senha = "1234vane";
		
		String usuario;
		String senhaa;
		
		System.out.print("Digite o usuario:");
		usuario = teclado.nextLine();
		System.out.print("Digite a senha:");
		senhaa = teclado.nextLine();
		
		u.login(usuario, senhaa);
		u.exibirStatus();
		if(u.logado == true) {
			int op=0;
			do {
			System.out.println("Deseja fazer logout? (1-sim, 2-não)");
				 op= teclado.nextInt();
				if(op==1) {
					u.logout();
					u.exibirStatus();
				}else if(op==2) {
					System.out.println("usuario segue logado");
				}else {
					System.out.println("opção invalida");
				}
			}while(op!=1 && op!=2);
		}
		
		teclado.close();
	}

}
