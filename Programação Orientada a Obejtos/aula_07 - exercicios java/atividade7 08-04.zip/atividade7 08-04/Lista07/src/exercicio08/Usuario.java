package exercicio08;

public class Usuario {
	public String nomeUsuario;
	public String senha;
	public boolean logado = false;
	
	public void login(String Usuario, String senhaa) {
		if(nomeUsuario.equals(Usuario)) {
			if(senha.equals(senhaa) ) {
				System.out.println("LOGIN REALIZADO COM SUCESSO");
				logado=true;
			}
		}else {
			if(!nomeUsuario.equals(Usuario)  && !senha.equals(senhaa) ) {
				System.out.println("usuario e senha invalido");
			}else if(!nomeUsuario.equals(Usuario)) {
				System.out.println("usuario invalido");
			}else if(!senha.equals(senhaa)){
				System.out.println("senha invalida");
			}
		}
	}
	
	public void logout() {
		this.logado = false;
		System.out.println("logout realizado com sucesso");
	}
	
	public void exibirStatus() {
		System.out.println("\nExibindo status do usuario");
		if(logado == false) {
			System.out.println("usuário não está logado\n");
		}else {
			System.out.println("usuário está logado\n");
		}
	}
}
