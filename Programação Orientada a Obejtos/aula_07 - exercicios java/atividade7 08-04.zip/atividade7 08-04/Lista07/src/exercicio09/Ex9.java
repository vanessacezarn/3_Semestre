//9) Crie uma classe Filme com os atributos:titulo (String)diretor (String)duracaoEmMinutos (int)genero (String)
//Crie os métodos:exibirDetalhes() para mostrar todas as informações do filme
//ehLongo() que retorna true se o filme tiver mais de 120 minutos
//Na Main:Peça ao usuário os dados de um filme e mostre os detalhes e se ele é considerado um filme longo

package exercicio09;

import java.util.Scanner;

public class Ex9 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);
		
		Filme f = new Filme();
		
		System.out.print("Digite o titulo do filme: ");
		f.titulo=teclado.nextLine();
		System.out.print("Digite o nome do diretor do filme: ");
		f.diretor=teclado.nextLine();
		System.out.print("Digite o gênero do filme: ");
		f.genero=teclado.nextLine();
		System.out.print("Digite a duração do filme em minutos: " );
		f.duracaoEmMinutos =teclado.nextInt();
		
		f.exibirDetalhes();
		
		int retorno = f.ehLongo();
		if(retorno == 2) {
			System.out.println("o filme não é considerado longo");
		}else if(retorno == 1) {
			
			System.out.println("o filme é considerado longo");
		}
		
		teclado.close();
	}

}
