package exercicio09;

public class Filme {
	public String titulo;
	public String diretor;
	public String genero;
	public int duracaoEmMinutos;
	
	public void exibirDetalhes() {
		System.out.println("\n\tExibindo informações do filme");
		System.out.println("Titulo do filme: "+titulo);
		System.out.println("Diretor do filme: "+diretor);
		System.out.println("Gênero do filme: "+genero);
		System.out.println("Duração do filme em minutos: "+duracaoEmMinutos );
	}
	
	public int ehLongo() {
		if (duracaoEmMinutos>120) {
			return 1;
		}else {
			return 2;
		}
	}
}
