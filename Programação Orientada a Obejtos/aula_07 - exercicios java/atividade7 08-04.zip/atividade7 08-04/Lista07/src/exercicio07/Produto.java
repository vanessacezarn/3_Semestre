package exercicio07;

public class Produto {
	public String nome;
	public double preco;
	public int quantidade;
	
	public void exibaInformacoes() {
		System.out.println("Exibindo informações");
		System.out.println("Nome do produto: "+nome);
		System.out.println("Preço do produto: "+preco);
		System.out.println("Quantidade do produto: "+quantidade);

	}

	public double calcularValorTotal() {
		return preco*quantidade;
	}
}
