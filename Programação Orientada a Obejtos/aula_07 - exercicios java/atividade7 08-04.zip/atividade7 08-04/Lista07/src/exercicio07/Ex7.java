//7) Crie uma classe Produto com os atributos:nome (String)preco (double)quantidade (int)
//Implemente:Um método exibirInformacoes() que exibe os dados do produto.Um método calcularValorTotal() que retorna o valor total em estoque (preço x quantidade)
//Na Main:Crie dois produtos, sendo um com valores informados via teclado e outro com valores definidos no código
//Exiba as informações e o valor total de cada produto

package exercicio07;

import java.util.Scanner;

public class Ex7 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);
		Produto p1 = new Produto();
		System.out.print("digite o nome do produto: ");
		p1.nome=teclado.nextLine();
		System.out.print("digite o preço do produto: ");
		p1.preco=teclado.nextDouble();
		System.out.print("digite a quantidade do produto: ");
		p1.quantidade=teclado.nextInt();
		System.out.println("\n\tPRODUTO 1");
		p1.exibaInformacoes();
		double retorno = p1.calcularValorTotal();
		System.out.println("Valor total do prduto = "+retorno);
		
		
		Produto p2 = new Produto();
		p2.nome="teclado";
		p2.preco=30;
		p2.quantidade=150;
		System.out.println("\n\tPRODUTO 2");
		p2.exibaInformacoes();
		double retorno2 = p2.calcularValorTotal();
		System.out.println("Valor total do prduto = "+retorno2);
		
		
		teclado.close();
	}

}
