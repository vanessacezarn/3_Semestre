package questao2;

public class Principal {

	public static void main(String[] args) {

		Televisao tv = new Televisao();
		tv.ligar();
		tv.desligar();
		
		Lampada l = new Lampada();
		l.ligar();
		l.desligar();
	}

}
