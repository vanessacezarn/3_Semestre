package questao2;

public interface Controlavel {
	abstract void ligar();
	abstract void desligar();
}
