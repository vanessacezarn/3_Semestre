/**
 * 
 */
/**
 * 
 */
module exercicio06_slides {
}