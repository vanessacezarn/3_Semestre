//6) Criar uma classe chamada Aluno com 3 construtores, sendo que o primeiro recebe o nome e a matrícula do aluno, o segundo recebe 
//apenas a data de nascimento do aluno e o terceiro construtor recebe o nome do aluno, a data de nascimento e o ano em que o aluno 
//ingressou na faculdade.Crie uma classe principal, com 3 objetos, cada um instanciando a classe com um construtor diferente.

package exercicio06;

public class Aluno {
	String nome;
	int matricula=0;
	String data_nascimento;
	int ano_ingresso;
	
	public Aluno (String nomeAluno, int matriculaAluno) {
		nome = nomeAluno;
		matricula = matriculaAluno;
		System.out.println();
		System.out.println("Utilizando o construtor 1");
		System.out.println("Nome: "+nome);
		System.out.println("Matricula: "+matricula);
		System.out.println();
		
	}

	public Aluno(String data_nascimentoAluno) {
		data_nascimento = data_nascimentoAluno;
		System.out.println("Utilizando o construtor  2");
		System.out.println("Data de nascimento: "+data_nascimento);
		System.out.println();
	}
	
	public Aluno(String nomeAluno, String data_nascimentoAluno, int ano_ingressoAluno) {
		nome = nomeAluno;
		data_nascimento = data_nascimentoAluno;
		ano_ingresso = ano_ingressoAluno;
		System.out.println("Utilizando o construtor  3");
		System.out.println("Nome: "+nome);
		System.out.println("Data de nascimento: "+data_nascimento);
		System.out.println("Ano de ingresso: "+ano_ingresso);
	}
	
	
	
	
	
}
