using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace web.Pages.Usuarios
{
    public class DetalhesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
