using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace web.Pages.Usuarios
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
