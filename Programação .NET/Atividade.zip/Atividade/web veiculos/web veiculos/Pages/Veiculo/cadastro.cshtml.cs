using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using web_veiculos.Pages.Models;

namespace web_veiculos.Pages.Veiculo
{
    public class cadastroModel : PageModel
    {
        [BindProperty]// liga os dados do post na propiedade veiculo
        public veiculosDados veiculo {  get; set; } // esta permitindo o acesso aos dados de veiculosDados

        public void OnGet() // executado sempre que a pagina � acessada
        {
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid) // verifica se os dados inseridos s�o validos
            {
                return Page();
            }
            else
            {
                using (var writer = new StreamWriter("veiculos.txt", true))
                {
                    // ESCREVE OS DADOS NO ARQUIVO .txt
                    writer.WriteLine(veiculo.Marca + ";"+veiculo.Modelo + ";"+ veiculo.Renavam + ";"+ veiculo.AnoFabricacao + ";"+ veiculo.AnoModelo + ";");
                    // mensagem de sucesso para informar o usuario que o cadastro foi realizado com sucesso --> a mensagem aparece no index
                    TempData["Sucesso"] = "Ve�culo cadastrado com sucesso!";
                    // apos o cadastro o usuario � redirecionado para a pagina de index
                    return RedirectToPage("/Veiculo/Index");
                }
            }
        }
    }
}
