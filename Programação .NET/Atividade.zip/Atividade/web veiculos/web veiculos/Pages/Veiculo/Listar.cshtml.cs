using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using web_veiculos.Pages.Models;

namespace web_veiculos.Pages.Veiculo
{
    public class ListarModel : PageModel
    {
        public List<veiculosDados> veiculos { get; set; } // lista de veiculos

        public void OnGet()
        {
            veiculos = new List<veiculosDados>(); // inicializou a lista
            if (System.IO.File.Exists("veiculos.txt")) // verifica se o arquivo txt existe
            {
                var linhas = System.IO.File.ReadAllLines("veiculos.txt"); // le todas as linhas do arquivo txt e salva em linhas

                foreach (var linha in linhas)
                {
                    var dados = linha.Split(';'); // separa os dados a cada (;) e salva em dados

                    var veiculo = new veiculosDados()
                    {
                        Marca = dados[0],
                        Modelo = dados[1],
                        Renavam = dados[2],
                        AnoFabricacao = int.Parse(dados[3]),
                        AnoModelo = int.Parse(dados[4]),

                    };
                    // adiciona o usuario a lista instanciada no inicio 
                    veiculos.Add(veiculo);
                }
            }
        }
    }
}
