using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using web_veiculos.Pages.Models;

namespace web_veiculos.Pages.Veiculo
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
