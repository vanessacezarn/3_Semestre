using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using web_veiculos.Pages.Models;

namespace web_veiculos.Pages.Veiculo
{
    public class EditarModel : PageModel
    {
        [BindProperty]
        public veiculosDados veiculo { get; set; }

        public IActionResult OnGet( string renavam)
        {
            if (string.IsNullOrWhiteSpace(renavam))
                return Page(); // se nenhum renavam foi digitado a pagina mostra a op�ao para o usuario digitar um renavam

            var veiculos = LerVeiculos(); // chama o metodo lerveiculos() 
            veiculo = veiculos.FirstOrDefault(v => v.Renavam == renavam); // procura o veiculo que tem o renavam igual ao digitado

            if (veiculo == null) // quando o renavam digitado n�o pertence a nenhum veiculo cadastrado
            {
                TempData["Erro"] = $"Ve�culo com RENAVAM {renavam} n�o encontrado.";

                return Page(); // permanece na pagina inicial que pede para o usuario digitar o renavam
            }

            return Page();
        }
        
         public IActionResult OnPost()
        {
            if (!ModelState.IsValid) // verifica se os dados inseridos s�o validos
                return Page();

            if (!System.IO.File.Exists("veiculos.txt")) { // verifica se o arquivo txt existe
                TempData["Erro"] = $"Arquivo n�o encontrado"; // mensagem informando erro
                return Page();
            }
            var linhas = System.IO.File.ReadAllLines("veiculos.txt").ToList();// le todos os dados do arquivo txt e o salva em uma lista de strings
            // procura o veiculo pelo renavam e quando acha substitui aquela linha pelas novas informa��es
            for (int i = 0; i < linhas.Count; i++)
            {
                var dados = linhas[i].Split(';');

                if (dados.Length >= 5 && dados[2] == veiculo.Renavam)
                {
                    linhas[i] = $"{veiculo.Marca};{veiculo.Modelo};{veiculo.Renavam};{veiculo.AnoFabricacao};{veiculo.AnoModelo};";
                    break;
                }
            }

            System.IO.File.WriteAllLines("veiculos.txt", linhas); // reescreve a o arquivo txt com as informa��es atualizadas
            TempData["Sucesso"] = "Ve�culo editado com sucesso!"; // informa ao usuario que e edi��o foi feitta com sucesso
            return RedirectToPage("/Veiculo/Index"); //direciona o usuario para a pagina do index
        }

        private List<veiculosDados> LerVeiculos() // usado para ler um veiculo
        {
            var veiculos = new List<veiculosDados>(); // lista que armazena todos os veiculos
            if (!System.IO.File.Exists("veiculos.txt")) // verifica se o arquivo txt existe
            {
                return veiculos; //retorna a lista vazia
            }
            var linhas = System.IO.File.ReadAllLines("veiculos.txt"); // le todo veiculo e cada linha representa um veiculo
            foreach(var linha in linhas)
            {
                var dados = linha.Split(';'); // separa os dados a cada ;

                if (dados.Length >= 5) // verifica se a linha tem 5 campos
                {
                    var veiculo = new veiculosDados()
                    {
                        Marca = dados[0],
                        Modelo = dados[1],
                        Renavam = dados[2],
                        AnoFabricacao = int.Parse(dados[3]),
                        AnoModelo = int.Parse(dados[4]),
                    };
                    // adiciona o veiculo a lista
                    veiculos.Add(veiculo);
                }
            }
            return veiculos;
        }
    }
}
