using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using web_veiculos.Pages.Models;

namespace web_veiculos.Pages.Veiculo
{
    public class visualizarModel : PageModel
    {
        public List<veiculosDados> veiculos { get; set; }
        public veiculosDados? VeiculoSelecionado { get; set; } // armazena o veiculo selecionado, e pode ser nula pois pode ser que nenhum veiculo tenha sido selecionado

        public void OnGet(string? Renavam) // o metodo pode receber como parametro uma string e ela pode estar vazia - ela est� vazia quando nenhum veiculo foi selecionado
        {

            veiculos = new List<veiculosDados>();
            if (System.IO.File.Exists("veiculos.txt"))
            {
                var linhas = System.IO.File.ReadAllLines("veiculos.txt");

                foreach (var linha in linhas)
                {
                    var dados = linha.Split(';');

                    var veiculo = new veiculosDados()
                    {
                        Marca = dados[0],
                        Modelo = dados[1],
                        Renavam = dados[2],
                        AnoFabricacao = int.Parse(dados[3]),
                        AnoModelo = int.Parse(dados[4]),



                    };
                    veiculos.Add(veiculo);
                    
                }
                if (!string.IsNullOrEmpty(Renavam))// verifica se renavam � vazia
                {
                    // se o renavam n�o � vazio
                    // procura o veiculo que tem o renavam passado como parametro 
                    VeiculoSelecionado = veiculos.FirstOrDefault(v => v.Renavam == Renavam);
                }

            }
        }
    }
}

