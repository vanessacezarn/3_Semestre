﻿namespace web_veiculos.Pages.Models
{
    public class veiculosDados
    {
        public string Modelo { get; set; }
        public string Marca { get; set; }
        public string Renavam { get; set; }
        public int AnoFabricacao { get; set; }
        public int AnoModelo { get; set; }






    }
}
