﻿//3 - Crie uma classe abstrata "ContaBancaria" com propriedades para "Saldo" e métodos abstratos "Depositar" e "Sacar". Crie classes derivadas,
//como "ContaCorrente" e "ContaPoupanca", que implementam os métodos de depósito e saque de acordo com as regras de cada tipo de conta.

using System;
using System.Threading.Channels;

namespace exercicio03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ContaCorrente cc = new ContaCorrente();
            cc.saldo = 1500.00;
            ContaPoupanca pp = new ContaPoupanca();
            pp.saldo = 2000.00;

            int op = 5, opc = 6;
            do
            {
                if (op == 5)
                {
                    Console.WriteLine("\n\tMENU CONTA");
                    Console.WriteLine("1 - Conta Corrente");
                    Console.WriteLine("2 - Conta Poupança");
                    Console.WriteLine("3 - SAIR");
                    Console.Write("escolha uma  opção: ");
                    op = int.Parse(Console.ReadLine());
                }
                if (op == 3)
                {
                    Console.WriteLine("FIM DO PROGRAMA");
                    break;
                }
                else if (op != 1 && op != 2)
                {
                    Console.WriteLine("opção invalidada");
                    op = 5;
                }
                else
                {
                    opc = 6;
                    while (opc != 5)
                    {
                        Console.WriteLine("\n\tMENU TRASAÇÕES");
                        Console.WriteLine("1 - sacar");
                        Console.WriteLine("2 - depositar");
                        Console.WriteLine("3 - saldo");
                        Console.WriteLine("4 - voltar ao menu anterior");
                        Console.WriteLine("5 - SAIR");
                        Console.Write("Digite uma opção: ");
                        opc = int.Parse(Console.ReadLine());

                        if (opc == 4) {

                            op = 5;
                            opc = 5;
                        }
                        else if (opc == 1)
                        {
                            if (op == 1)
                            {
                                Console.Write("digite o valor que deseja sacar da Conta Corrente : ");
                                cc.saque = double.Parse(Console.ReadLine());
                                cc.Sacar();
                            }
                            else if (op == 2)
                            {
                                Console.Write("digite o valor que deseja sacar da Conta Poupança : ");
                                pp.saque = double.Parse(Console.ReadLine());
                                pp.Sacar();

                            }
                        }
                        else if (opc == 2)
                        {
                            if (op == 1)
                            {
                                Console.Write("digite o valor que deseja depositar na Conta Corrente : ");
                                cc.deposito = double.Parse(Console.ReadLine());
                                cc.Depositar();
                            } else if (op == 2)
                            {
                                Console.Write("Digite o valor que deseja depositar na Conta Poupança : ");
                                pp.deposito = double.Parse(Console.ReadLine());
                                pp.Depositar();
                            }

                        } else if (opc == 3)
                        { 
                            if (op == 1)
                            {
                                cc.SaldoDisponivel();
                            }
                            else if (op == 2)
                            {
                                pp.SaldoDisponivel();

                            }
                        }
                        else if (opc == 5)
                        {
                            Console.WriteLine("FIM DO PROGRAMA");
                            op = 3;
                        }
                        else
                        {
                            Console.WriteLine("opção invalida");

                        }
                    }
                }
            

            } while (op != 3);

            




        }
    }
}
