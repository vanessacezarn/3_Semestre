﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio03
{
    internal class ContaPoupanca : ContaBancaria
    {
        public double deposito;
        public double saque;

        public override void Depositar()
        {
            saldo += deposito;
            Console.WriteLine("Deposito feito com sucesso !!! "+saldo);


        }

        public override void Sacar()
        {
            if (saldo >= saque)
            {
                saldo -= saque;
                Console.WriteLine("Saque realizado com sucesso!!! ");

            }
            else
            {
                Console.WriteLine("saldo INSUFICIENTE para realizar um saque com esse valor");
            }
        }

        public override void SaldoDisponivel()
        {
            Console.WriteLine("o saldo disponivel na Conta Poupança é de R$ "+saldo);
        }
    }
}
