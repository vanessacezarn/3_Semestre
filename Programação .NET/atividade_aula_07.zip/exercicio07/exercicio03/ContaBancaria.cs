﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio03
{
    abstract class ContaBancaria
    {
        public double saldo ;

        public abstract void Depositar();

        public abstract void Sacar();
       
        public abstract void SaldoDisponivel();  
    }
}
