﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio03
{
    internal class ContaCorrente : ContaBancaria
    {
        public double deposito;
        public double saque;
        
        public override void Depositar()
        {
            saldo = saldo + deposito;
            Console.WriteLine("Deposito feito com sucesso !!! " );
        }

        public override void Sacar()
        {
            if(saldo >= saque)
            {
                this.saldo -= saque;
                Console.WriteLine("Saque realizado com sucesso!!! ");
            }
            else
            {
                Console.WriteLine("Saldo insuficiente para realizar o saque nesse valor");
            }
        }

        public override void SaldoDisponivel()
        {
            Console.WriteLine("o saldo disponivel na Conta Corrente é de R$ "+saldo);
        }
    }
}
