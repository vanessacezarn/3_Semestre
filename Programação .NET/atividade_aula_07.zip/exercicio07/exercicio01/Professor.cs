﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio01
{
    internal class Professor : Pessoa
    {
        public String disciplina;
        

        public override void apresentar()
        {
            Console.WriteLine("\nDados do professor");
            Console.WriteLine("nome: "+nome);
            Console.WriteLine("idade: "+idade);
            Console.WriteLine("disciplina: "+disciplina);
        }
        
    }
}
