﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio01
{
    internal class Aluno : Pessoa
    {
        public int matricula;
        public override void apresentar()
        {
            Console.WriteLine("\nDados do Aluno");
            Console.WriteLine("nome: "+nome);
            Console.WriteLine("idade: "+idade);
            Console.WriteLine("matricula: "+matricula);
        }
    }
}
