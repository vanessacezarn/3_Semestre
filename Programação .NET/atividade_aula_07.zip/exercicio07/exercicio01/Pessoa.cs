﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio01
{
    abstract class Pessoa
    {
        public String nome;
        public int idade;

        public abstract void apresentar ();
    }
}
