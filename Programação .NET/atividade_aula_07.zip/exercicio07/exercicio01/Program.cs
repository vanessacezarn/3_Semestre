﻿//1 - Criar uma classe Pessoa que contém as propriedades Nome e Idade. Criar duas classes derivadas, Aluno e Professor, que herdam de
//Pessoa.  A classe Aluno deve ter uma propriedade adicional Matricula, enquanto a classe Professor deve ter uma propriedade adicional
//Disciplina.  Criar um método abstrato Apresentar na classe Pessoa. Em seguida, criar um método Apresentar na classe Aluno que imprime
//o nome, a idade e a matrícula do aluno, e um método Apresentar na classe Professor que imprime o nome, a idade e a disciplina do
//professor.

namespace exercicio01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Professor p = new Professor();
            Console.Write("Digite o nome do professor: ");
            p.nome = Console.ReadLine();
            Console.Write("Digite a idade do professor: ");
            p.idade = int.Parse(Console.ReadLine());
            Console.Write   ("Digite a disciplina do professor: ");
            p.disciplina = Console.ReadLine();


            Aluno a = new Aluno();
            Console.Write("\nDigite o nome do aluno: ");
            a.nome = Console.ReadLine();
            Console.Write("Digite a idade do aluno: ");
            a.idade = int.Parse(Console.ReadLine());
            Console.Write("Digite a matricula do aluno: ");
            a.matricula = int.Parse(Console.ReadLine());

            p.apresentar();
            a.apresentar();


        }
    }
}
