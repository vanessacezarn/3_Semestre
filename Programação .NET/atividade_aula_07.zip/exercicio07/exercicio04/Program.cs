﻿//4 - Crie uma classe abstrata "Produto" com propriedades para "Nome", "Preço" e um método abstrato "CalcularDesconto".
//Crie classes derivadas para diferentes tipos de produtos, como "Livro" e "Eletrônico", que implementam o método "CalcularDesconto"
//de acordo com as regras específicas de desconto para cada tipo de produto.
//Livro – 5% de desconto / Eletrônico - 12.5 % de desconto
namespace exercicio04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Livro l = new Livro();

            Console.Write("Digite o nome do livro: ");
            l.nome = Console.ReadLine();
            Console.Write("informe o preço do livro: ");
            l.preco = double.Parse(Console.ReadLine());
            l.CalcularDesconto();
            
            Console.WriteLine("O valor do livro com desconto é de R$ "+l.preco);


            Eletronico e = new Eletronico();
            Console.Write("\nDigite o nome do eletronico: ");
            e.nome = Console.ReadLine();
            Console.Write("informe o preço do eletrônico: ");
            e.preco = double.Parse(Console.ReadLine());
            e.CalcularDesconto();

            Console.WriteLine("O valor do eletrônico com desconto é de R$ " + e.preco);

        }
    }
}
