﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio04
{
    internal class Livro : Produto
    {
        double desconto;
        public override void CalcularDesconto()
        {
            desconto = preco * 0.05;
            Console.WriteLine("o valor do desconto é de R$ "+desconto);
            preco = preco - desconto;
        }
    }
}
