﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio02
{
    internal class Carro : Veiculo
    {
        public int porta;
        public override void Dirigir()
        {
            Console.WriteLine("Dirigindo o " + marca + " " + modelo + " com " + porta + " portas");

        }
    }
}
