﻿//2 - Criar uma classe Veiculo que contém as propriedades Marca e Modelo. Criar um método abstrato chamado Dirigir. Criar duas classes derivadas,
//Carro e Moto, que herdam de Veiculo. A classe Carro deve ter uma propriedade adicional , enquanto a classe Moto deve ter uma propriedade
//adicional Cilindrada. Criar um método abstrato Dirigir na classe Veiculo. Em seguida, criar um método Dirigir na classe Carro que imprime
//"Dirigindo o <marca> <modelo> com<> portas" e um método Dirigir na classe Moto que imprime "Dirigindo a <marca> <modelo> com<cilindrada>
//cilindradas"


namespace exercicio02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Carro c = new Carro();
            Console.WriteLine("CARRO");
            Console.Write("Digite a marca do carro: ");
            c.marca = Console.ReadLine();
            Console.Write("Digite a modelo do carro: ");
            c.modelo = Console.ReadLine();
            Console.Write("Digite quantas portas tem o carro: ");
            c.porta = int.Parse(Console.ReadLine());

            Moto m =new Moto();
            Console.WriteLine("\nMOTO");
            Console.Write("Digite a marca da moto: ");
            m.marca = Console.ReadLine();
            Console.Write("Digite o modelo da moto: ");
            m.modelo = Console.ReadLine();
            Console.Write("Digite as cilindradas da moto: ");
            m.cilindradas = int.Parse(Console.ReadLine());

            Console.WriteLine("\n");
            c.Dirigir();
            m.Dirigir();

        }
    }
}
