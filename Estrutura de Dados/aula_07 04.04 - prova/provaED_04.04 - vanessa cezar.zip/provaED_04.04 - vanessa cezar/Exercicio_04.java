//Em sua linguagem de preferência, crie um programa (usando funções/métodos) que:
//preencha N nomes de equipes de futebol, obrigatóriamente em maiúsculo. Esses nomes devem ser armazenados em um dicionário que se possa controlar duplicados.
//exiba os nomes das equipes cadastradas
//exiba a quantidade de equipes cadastradas

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;



public class Exercicio_04 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        List<Map<String,String>> listaDeDicionario = new ArrayList<>();
        String equipe;
        int op;
        int contador=0;
        System.out.println("\tCADASTRO DE EQUIPE");
        do{
            System.out.print("digite o nome da equipe: ");
            equipe=teclado.nextLine().toUpperCase();
            
            Map<String, String> dicionario1 = new HashMap<>();
            dicionario1.put("nome", equipe);
           
            if(listaDeDicionario.contains(dicionario1)){
                System.out.println("Essa equipe já está cadastrado");
            }else{
                System.out.println("equipe cadastrado com sucesso!!1");
                listaDeDicionario.add(dicionario1);
                contador++;
            }
            
        
            do{
            System.out.print("Deseja cadastrar mais uma equipe? (1-sim, 2-não) : ");
            op=teclado.nextInt();
            teclado.nextLine();
            if(op!=1 && op!=2){
                System.out.println("opção invalida");
            }
            }while(op!=1 && op!=2);

        }while(op!=2);

        System.out.println("\nForam cadastradas "+contador+" equipes");
        System.out.println("\nEQUIPES CADASTRADAS");
        for(Map<String,String> dicionario : listaDeDicionario){
            System.out.println("nome equipe: "+ dicionario.get("nome"));
           
            System.out.println("-----------");
        }
        
        teclado.close();
    }
}