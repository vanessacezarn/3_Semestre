/*Ao usarmos listas de objetos com controle de duplicidade, precisamos reescrever o métodos equals() da classe que estamos implementando.
 Imagine uma classe Turma, em que há os atributos nome, cpf, dataNascimento. A partir daí, implemente a classe e reescreva o método equals() 
 que use o atributo cpf com identficador (chave primária) da classe. */
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

 class Turma{
    public String nome;
    public String cpf;
    public String data_nascimento;

    public Turma(String nome, String cpf, String data_nascimento) {
        this.nome = nome;
        this.cpf = cpf;
        this.data_nascimento = data_nascimento;
    }

    

    @Override
    public String toString() {
        return "Turma [nome=" + nome + ", cpf=" + cpf + ", data_nascimento=" + data_nascimento + "]";
    }



    @Override
    public boolean equals(Object obj) {
        Turma alunos = (Turma) obj;
        if(this.cpf.equals(alunos.cpf))
            return true;
        return false;
    }

    
    
}

public class Exercicio_03 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        List<Turma> aluno = new ArrayList<>();

        String nome;
        String cpf;
        String data_nascimento;
        int op =1;
        

        do{
        System.out.print("digite o nome do aluno:");
        nome = teclado.nextLine();
        System.out.print("digite o cpf do aluno:");
        cpf=teclado.nextLine();
        
        System.out.print("digite a data de nascimento do aluno:");
        data_nascimento=teclado.nextLine();
        Turma t = new Turma(nome,cpf,data_nascimento);
        if(aluno.contains(t)){
            System.out.println("Esse cpf já está cadastrado");
        }else{
            System.out.println("aluno cadastrado com sucesso");
            aluno.add(t);
        }

        do{
        System.out.print("Deseja cadastrar mais um aluno? (1-sim, 2-não)");
        op=teclado.nextInt();
        teclado.nextLine();
        if(op!=1 && op!=2){
            System.out.println("opção invalida");
        }
        }while(op!=1 && op!=2);
        

    }while(op!=2);

    System.out.println("Relacao aluno");
        for(Turma a : aluno){
            System.out.println(a);
        }
        teclado.close();
    }
}
