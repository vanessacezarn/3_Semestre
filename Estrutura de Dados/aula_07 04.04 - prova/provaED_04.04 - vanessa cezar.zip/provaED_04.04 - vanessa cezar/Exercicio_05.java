/*Em sua linguagem de preferência, crie um programa que manipule objetos cidades baseados na classe Cidade, contendo, nome da cidade e sigla do estado do Brasil. 
O controle de duplicidade deve ser via o nome da cidade. O programa deve apresentar um pequeno Menu, em que o usuário possa:
    cadastrar uma cidade em lista de cidades: nome completo em maiúsculo e a sigla em maiúsculo
    listar as cidades cadastradas tendo como ordem de ordenação os nomes das cidades
    pesquisar uma cidade por seu nome e mostrar o seu estado respectivo (no caso, sigla)
    remover uma cidade, pesquisando-a por seu nome
    finalizar o programa*/

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Cidade{
    public String nome_cidade;
    public String sigla_estado;

    public Cidade(String nome, String sigla_estado) {
        this.nome_cidade = nome;
        this.sigla_estado = sigla_estado;
    }

    public boolean equals(Object obj) {
        Cidade nomes = (Cidade) obj;
        if(this.nome_cidade.equals(nomes.nome_cidade))
            return true;
        return false;
    }

    @Override
    public String toString() {
        return "Cidade: " + nome_cidade + ", Estado: " + sigla_estado ;
    }

    public Cidade(String nome_cidade) {
        this.nome_cidade = nome_cidade;
    }
    

}

public class Exercicio_05 {
    public static void main(String[] args){
        Scanner teclado = new Scanner(System.in);
        List<Cidade> cidades = new ArrayList<>();
        
        String nome;
        String estado;
        int op;
        do{
            System.out.println("Menu");
            System.out.println("1 - cadastrar uma cidade em lista de cidades");
            System.out.println("2 - listar as cidades cadastradas");
            System.out.println("3 - pesquisar uma cidade por seu nome e mostrar o seu estado respectivo ");
            System.out.println("4 - remover uma cidade");
            System.out.println("5 - finalizar o programa");
            System.out.print("Escolha uma opção: ");
            op=teclado.nextInt(); 
            teclado.nextLine();

            if(op!=1 && op!=2 && op!=3 && op!=4 && op!=5 ){
                System.out.println("opção invalida");
            }
            if(op==1){
                System.out.println("\n CADASTRO DE CIDADES");
                System.out.print("digite o nome cidade:");
                nome = teclado.nextLine().toUpperCase();
                System.out.print("digite a sigla do estado da cidade:");
                estado=teclado.nextLine().toLowerCase();
                Cidade cid = new Cidade(nome, estado);
                if(cidades.contains(cid)){
                    System.out.println("\nesta cidade já está cadastrada!!\n");
                }else{
                    System.out.println("\ncidade cadastrado com sucesso!!\n");
                    cidades.add(cid);
                }
            }else if(op==2){
                System.out.println("\nCIDADES CADASTRADAS\n");
                for(Cidade a : cidades){
                    System.out.println(a);
                }
            }else if(op==3){
                
                String nome_pesquisa;
                System.out.println("\nPESQUISA DE UMA CIDADE");
                System.out.print("digite o nome da cidade: ");
                nome_pesquisa=teclado.nextLine().toUpperCase();
                Cidade pesquisa = new Cidade(nome_pesquisa);
                if(cidades.contains(pesquisa)){
                    System.out.println("\ncidade encontrada no cadastrado\n");
                    
                    
                }else{
                    System.out.println("\ncidade não está no cadastrado !!\n");
                    cidades.add(pesquisa);

                }

            }else if(op==4){
                System.out.println("\nREMOVER CIDADE");
            }else if(op==5){
                System.out.println("FIM DO PROGRAMA");
            }
        }while(op!=5);

        teclado.close();
    }
}
