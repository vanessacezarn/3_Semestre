﻿namespace exercicio_04
{
    class Livro
    {
        public String titulo;
        public String autor;
        public int ano_publicacao;
    }
}
