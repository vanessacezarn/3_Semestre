﻿//3 - Crie uma classe chamada Carro que possua 3 atributos: marca, modelo e anoFabricacao. Além disso, na main crie 2 objetos
//do tipo Carro e exibir na tela os valores dos atributos criados. Esses valores devem ser solicitados ao usuário, no
//programa.

namespace exercicio_03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Carro 1");
            Carro c = new Carro();
            Console.Write("Digite a marca:");
            c.marca = Console.ReadLine();
            Console.Write("Digite o modelo:");
            c.modelo = Console.ReadLine();
            Console.Write("Digite o ano de fabricação:");
            c.anoFabricacao = int.Parse(Console.ReadLine());

            Console.WriteLine("Carro 2");
            Carro c2 = new Carro();
            Console.Write("Digite a marca:");
            c2.marca = Console.ReadLine();
            Console.Write("Digite o modelo:");
            c2.modelo = Console.ReadLine();
            Console.Write("Digite o ano de fabricação:");
            c2.anoFabricacao = int.Parse(Console.ReadLine());

            
            Console.WriteLine("\nInformações digitadas");
            Console.WriteLine("Carro 1 ");
            Console.WriteLine("marca: " + c.marca);
            Console.WriteLine("modelo: " + c.modelo);
            Console.WriteLine("Ano de fabricação: " + c.anoFabricacao);
            
            Console.WriteLine("\nCarro 2 ");
            Console.WriteLine("marca: " + c2.marca);
            Console.WriteLine("modelo: " + c2.modelo);
            Console.WriteLine("Ano de fabricação: " + c2.anoFabricacao);
        }
    }
}
