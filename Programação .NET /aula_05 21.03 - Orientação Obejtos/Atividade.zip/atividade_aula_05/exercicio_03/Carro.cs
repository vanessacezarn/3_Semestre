﻿namespace exercicio_03
{
    class Carro
    {
        public String marca;
        public String modelo;
        public int anoFabricacao;
    }
}
