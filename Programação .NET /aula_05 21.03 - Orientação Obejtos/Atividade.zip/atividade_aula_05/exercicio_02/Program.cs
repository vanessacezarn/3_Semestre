﻿//2 - Crie uma classe "Estúdio" com os seguintes atributos: Nome, Ano de fundação, País de origem e Número de jogos
//produzidos. Na main, instancie um objeto e faça a leitura pelo teclado.

namespace exercicio_02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Estudio est = new Estudio();

            Console.Write("Digite o nome do estúdio: ");
            est.nome = Console.ReadLine();
            Console.Write("Digite o ano de fundação: ");
            est.ano_fundacao = int.Parse(Console.ReadLine());
            Console.Write("Digite o país de origem: ");
            est.pais_origem = Console.ReadLine();
            Console.Write("Digite o número de jogo produzido: ");
            est.numeros_jogos = int.Parse(Console.ReadLine());

            Console.WriteLine();
            Console.WriteLine("Informações sobre o Estúdio *"+est.nome+"*");
            Console.WriteLine("Ano de fundação: "+est.ano_fundacao);
            Console.WriteLine("País de origem: "+est.pais_origem);
            Console.WriteLine("Números de jogo produzido: "+est.numeros_jogos);

        }
    }
}
