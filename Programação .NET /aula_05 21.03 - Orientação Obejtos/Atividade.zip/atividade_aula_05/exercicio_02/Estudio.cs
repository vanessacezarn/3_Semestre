﻿namespace exercicio_02
{
    class Estudio
    {
        public String nome;
        public int ano_fundacao;
        public String pais_origem;
        public int numeros_jogos;
    }
}
