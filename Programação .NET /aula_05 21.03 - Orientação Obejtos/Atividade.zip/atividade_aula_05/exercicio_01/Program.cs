﻿//1 - Crie uma classe "Jogo" com os seguintes atributos: Título, Gênero, Plataforma (por exemplo, PC, Xbox, PlayStation),
//Ano de lançamento. Na main, instancie um objeto e faça a leitura pelo teclado.

namespace exercicio_01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Jogo j = new Jogo();

            Console.Write("Digite o título do jogo: ");
            j.titulo = Console.ReadLine();
            Console.Write("Digite o gênero do jogo: ");
            j.genero = Console.ReadLine();
            Console.Write("Digite a plataforma do jogo (PC, Xbox, PlayStantio) :");
            j.plataforma = Console.ReadLine();
            Console.Write("Digite o ano do lançamento do jogo: ");
            j.ano_lancameneto = int.Parse(Console.ReadLine());

            Console.WriteLine( );
            Console.WriteLine("Dados do jogo *"+j.titulo+"*");
            Console.WriteLine("gênero: "+j.genero);
            Console.WriteLine("plataforma :"+j.plataforma);
            Console.WriteLine("ano de lançamento do jogo: "+j.ano_lancameneto);
        }
    }
}
