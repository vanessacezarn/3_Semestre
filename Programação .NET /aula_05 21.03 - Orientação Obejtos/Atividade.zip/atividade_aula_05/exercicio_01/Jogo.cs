﻿namespace exercicio_01
{
    class Jogo
    {
        public String titulo;
        public String genero;
        public String plataforma;
        public int ano_lancameneto;
           
    }
}
