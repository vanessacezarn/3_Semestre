﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01
{
    internal class gato : Animal
    {
        public override void emitirSom()
        {
            Console.WriteLine("MIAU");        
        }
        public void ronronar()
        {

            Console.WriteLine("o gato está ronrondo");
        }
    }
}
