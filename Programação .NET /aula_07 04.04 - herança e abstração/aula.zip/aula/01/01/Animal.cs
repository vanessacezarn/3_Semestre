﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01
{
    abstract class Animal
    {
        public String nome;

        public abstract void emitirSom(); // metodo abstrato -> tem que implementar nas outras classes
        //virtual = informe que o metodo pode ser reimplementado
        public virtual void movimentar() // metodo concreto -> não precisa implementar em todas as outras classes
        {
            Console.WriteLine("o animal está se movimentando");
        }
        
    }
}
