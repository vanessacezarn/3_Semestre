﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01
{
    internal class peixe : Animal
    {
        public override void emitirSom()
        {
            Console.WriteLine("glub glub");
        }
        public override void movimentar()
        {
            Console.WriteLine(" o peixe está nadando");
        }

    }
}
