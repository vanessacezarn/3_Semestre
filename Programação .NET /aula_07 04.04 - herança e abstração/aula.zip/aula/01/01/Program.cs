﻿namespace _01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("teste");
            Cachorro C = new Cachorro();
            C.nome = "Toby";
            Console.WriteLine("Cachorro: "+C.nome);
            C.raca = "salsicha";
            Console.WriteLine("raça: "+C.raca);
            C.movimentar();
            C.emitirSom();

            gato g = new gato();
            g.nome = "amora";
            Console.WriteLine("\nGato: " + g.nome);
            g.emitirSom();
            g.ronronar();
            g.movimentar();

            peixe p = new peixe();
            p.nome = "nemo";
            Console.WriteLine("\nPeixe: " + p.nome);
            p.emitirSom();
            p.movimentar();

        }
    }
}