using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using web.Models;

namespace web.Pages.Usuarios
{
    public class IndexModel : PageModel
    {
        public List<Usuario> Usuarios { get; set; }

        public void OnGet()
        {
            Usuarios = new List<Usuario>(); // INSTANCIA A LISTA ONDE ESTA ARMAZENADO OS USUARIOS

            if (System.IO.File.Exists("usuarios.txt")) //VERIFICA SE O ARQUIVO EXISTE
            {
                var linhas = System.IO.File.ReadAllLines("usuarios.txt");

                foreach(var linha in linhas)
                {
                    var dados = linha.Split(';'); // DIVIDINDO A LINHA E CADA REGISTRO

                    var usuario = new Usuario() // LER AS LINHAS DO ARQUIVO E ARMAZENA NUM ARRAY DE STRIGS
                    {
                        Id = int.Parse(dados[0]),
                        Nome = dados[1],
                        Senha = dados[2],
                        Email = dados[3]
                    };
                    // ADICIONAR O USUARIO A LISTA QUE EU INSTANCIEI LA NO INICIO
                    Usuarios.Add(usuario);
                }
            }
        }
    }
}
