using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using web.Models;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace web.Pages.Usuarios
{
    public class EditarModel : PageModel
    {
        [BindProperty]
        public Usuario Usuario { get; set; }

        public IActionResult OnGet(int id)
        {
            var usuarios = LerUsuarios();
            Usuario = usuarios.FirstOrDefault(u => u.Id == id);

            if (Usuario == null)
            {
                return NotFound(); // Usu�rio n�o encontrado
            }

            return Page();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
                return Page();

            var caminho = "usuarios.txt";

            if (!System.IO.File.Exists(caminho))
                return NotFound("Arquivo de usu�rios n�o encontrado.");

            var linhas = System.IO.File.ReadAllLines(caminho).ToList();

            for (int i = 0; i < linhas.Count; i++)
            {
                var dados = linhas[i].Split(';');

                if (int.TryParse(dados[0], out int id) && id == Usuario.Id)
                {
                    linhas[i] = $"{Usuario.Id};{Usuario.Nome};{Usuario.Senha};{Usuario.Email}";
                    break;
                }
            }

            System.IO.File.WriteAllLines(caminho, linhas);

            return RedirectToPage("/Usuarios/Index");
        }

        private List<Usuario> LerUsuarios()
        {
            var usuarios = new List<Usuario>();

            var caminho = "usuarios.txt";

            if (!System.IO.File.Exists(caminho))
                return usuarios;

            var linhas = System.IO.File.ReadAllLines(caminho);

            foreach (var linha in linhas)
            {
                var dados = linha.Split(';');

                if (dados.Length >= 4 &&
                    int.TryParse(dados[0], out int id))
                {
                    var usuario = new Usuario
                    {
                        Id = id,
                        Nome = dados[1],
                        Senha = dados[2],
                        Email = dados[3]
                    };

                    usuarios.Add(usuario);
                }
            }

            return usuarios;
        }
    }
}
