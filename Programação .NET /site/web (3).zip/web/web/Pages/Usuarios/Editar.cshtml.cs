using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using web.Models;

namespace web.Pages.Usuarios
{
    public class EditarModel : PageModel
    {
		public Usuario Usuario { get; set; }
		public IActionResult OnGet(int id)
        {
			var usuarios = EditarUsuarios();

			Usuario = usuarios.FirstOrDefault(usuarios => usuarios.Id == id);

			if (Usuario == null)
			{
				return RedirectToPage("/Usuario/Index");
			}

			return Page();
		}
	}
    

}
