﻿//2- Crie uma classe Livro que represente os dados básicos de um livro, além destes, criar um atributo do tipo boolean chamado emprestado.
//Crie métodos emprestar e devolver que altera o atributo emprestado
//Crie um método construtor que receba todos os valores por parâmetros, exceto o atributo emprestado que obrigatoriamente
//deve ser inicializado como false
//Faça a leitura pelo teclado dos atributos para instanciar dois livros

namespace Exercicio02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            String titulo;
            String autor;
            String editora;
            String genero;
            int anoPublicacao;

            Console.WriteLine("** LIVRO 1 **");
            Console.Write("Digite o titulo do livro: ");
            titulo = Console.ReadLine();
            Console.Write("Digite o autor do livro: ");
            autor = Console.ReadLine();
            Console.Write("Digite a editora do livro: ");
            editora = Console.ReadLine();
            Console.Write("Digite o genero do livro: ");
            genero = Console.ReadLine();
            Console.Write("Digite o ano de publicação do livro: ");
            anoPublicacao = int.Parse(Console.ReadLine());
            Livro l1 = new Livro(titulo, autor, editora, genero, anoPublicacao);


            String titulo2;
            String autor2;
            String editora2;
            String genero2;
            int anoPublicacao2;

            Console.WriteLine(" \n ** LIVRO 2 **");
            Console.Write("Digite o titulo do livro: ");
            titulo2 = Console.ReadLine();
            Console.Write("Digite o autor do livro: ");
            autor2 = Console.ReadLine();
            Console.Write("Digite a editora do livro: ");
            editora2 = Console.ReadLine();
            Console.Write("Digite o genero do livro: ");
            genero2 = Console.ReadLine();
            Console.Write("Digite o ano de publicação do livro: ");
            anoPublicacao2 = int.Parse(Console.ReadLine());
            Livro l2 = new Livro(titulo2, autor2, editora2, genero2, anoPublicacao2);



            int menuPrincipal = 5;

            do
            {
                //int menuPrincipal = 5;
                int menu = 5;
                if (menuPrincipal == 5)
                {
                    Console.WriteLine("\n\t MENU LIVROS");
                    Console.WriteLine("1) " + titulo);
                    Console.WriteLine("2) " + titulo2);
                    Console.WriteLine("3) SAIR");
                    Console.Write("Qual livro deseja? ");
                    menuPrincipal = int.Parse(Console.ReadLine());
                }

                if (menuPrincipal != 1 && menuPrincipal != 2 && menuPrincipal != 3)
                {
                    Console.WriteLine("opção invalidade");
                    menuPrincipal = 5;
                }
                else
                {
                    if (menuPrincipal == 3)
                    {
                        Console.WriteLine("\nFIM DO PROGRAMA");
                        break;
                    }
                    else
                    {

                        while (menu != 0)
                        {
                            Console.WriteLine("\n\tMENU OPÇÕES");
                            Console.WriteLine("1 - informações sobre o livro");
                            Console.WriteLine("2 - emprestimo");
                            Console.WriteLine("3 - devolução");
                            Console.WriteLine("4 - voltar ao menu livro");
                            Console.WriteLine("5 - Sair");
                            Console.Write("Escolha uma opção: ");
                            menu = int.Parse(Console.ReadLine());
                            if (menu != 1 && menu != 2 && menu != 3 && menu != 4 && menu != 5)
                            {
                                Console.WriteLine("Opção invalida");
                            }
                            if(menu == 1)
                            {
                                if (menuPrincipal == 1)
                                {
                                    Console.WriteLine("\n Informações sobre o livro");
                                    l1.informacoes();
                                }
                                else
                                {
                                    if(menuPrincipal==2) {
                                        Console.WriteLine("\n Informações sobre o livro");
                                        l2.informacoes();
                                    }
                                }
                            }
                            if (menu == 2)
                            {

                                Boolean emprestado;
                                if (menuPrincipal == 1)
                                {
                                    emprestado = l1.Emprestar();
                                }
                                else
                                {
                                    emprestado = l2.Emprestar();
                                }

                                Console.WriteLine("\n EMPRESTIMOS");
                                if (!emprestado)
                                {
                                    Console.WriteLine("livro disponivel para emprestimo");
                                    int opc;
                                    do
                                    {
                                        Console.Write("deseja pegar o livro emprestado? (1-sim ,2 -não): ");
                                        opc = int.Parse(Console.ReadLine());
                                        if (opc != 1 && opc != 2)
                                        {
                                            Console.WriteLine("opção invalida! tente novamente");
                                        }
                                    } while (opc != 1 && opc !=2);
                                    if (opc == 1)
                                    {
                                        if (menuPrincipal == 1)
                                        {
                                            l1.emprestado = true;
                                        }
                                        else
                                        {                                            
                                            l2.emprestado = true;
                                        }


                                        Console.WriteLine("livro EMPRESTADO com sucesso!!!");
                                    }
                                    else
                                    {
                                        Console.WriteLine("livro segue disponivel");
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("livro não está disponivel para emprestimo");
                                }
                            }
                            if (menu == 3)
                            {
                                Boolean devolucao;
                                if (menuPrincipal == 1)
                                {
                                    devolucao = l1.Devolver();
                                }
                                else
                                {
                                    devolucao = l2.Devolver();
                                }

                                Console.WriteLine("\n DEVOLUÇÃO");
                                if (devolucao)
                                {
                                    
                                    int op;
                                    do
                                    {
                                       
                                        Console.Write("Deseja realizar a devolução do livro ? (1-sim, 2-não): ");
                                        op = int.Parse(Console.ReadLine());
                                        
                                        if (op != 1 && op != 2)
                                        {
                                            Console.WriteLine("opção invalida! tente novamente");
                                        }
                                    } while (op != 1 && op != 2);
                                    if (op == 1)
                                    {
                                        Console.WriteLine("Livro DEVOLVIDO com successo!!!");
                                        l1.emprestado = false;
                                    }
                                    else
                                    {
                                        Console.WriteLine("Livro continua emprestado");
                                    }
                                }
                                else
                                {
                                    Console.WriteLine(" o livro não está emprestado, logo não é possivel fazer devolução");
                                }
                            }
                            if (menu == 4)
                            {
                                menuPrincipal = 5;
                                menu = 0;

                            }

                            if (menu == 5)
                            {

                                Console.WriteLine("\n FIM DO PROGRAMA");
                                menu = 0;
                                menuPrincipal = 0;
                            }
                        }

                    }
                }
            } while (menuPrincipal != 0) ;
   

            
        }
    } 
}
