﻿//2- Crie uma classe Livro que represente os dados básicos de um livro, além destes, criar um atributo do tipo boolean chamado emprestado.
//Crie métodos emprestar e devolver que altera o atributo emprestado
//Crie um método construtor que receba todos os valores por parâmetros, exceto o atributo emprestado que obrigatoriamente
//deve ser inicializado como false
//Faça a leitura pelo teclado dos atributos para instanciar dois livros


namespace Exercicio02
{
    class Livro
    {
        public String titulo;
        public String autor;
        public String editora;
        public String genero;
        public int anoPublicacao;
        public Boolean emprestado = false;

        public Livro(string titulo, string autor, string editora, string genero, int anoPublicacao)
        {
            this.titulo = titulo;
            this.autor = autor;
            this.editora = editora;
            this.genero = genero;
            this.anoPublicacao = anoPublicacao;
        }

        public Boolean Emprestar()
        {
            if (!emprestado)
            {
                return false;
            }
            else
            {
                emprestado = true;
                return true;
            }
        }

        public Boolean Devolver()
        {
            if (!emprestado)
            {
                return false;
            }
            else
            {
                emprestado = true;
                return true;
            }
        }

        public void informacoes()
        {
            Console.WriteLine("Titulo : " + titulo);
            Console.WriteLine("Autor : " + autor);
            Console.WriteLine("Gênero : " + genero);
            Console.WriteLine("Editora : " + editora);
            Console.WriteLine("Ano de publicação : " + anoPublicacao);
            if (!emprestado)
            {
                Console.WriteLine("O livro está disponível na biblioteca");
            }
            else
            {
                Console.WriteLine("O livro está emprestado");
            }

        }
       
        }
    }
