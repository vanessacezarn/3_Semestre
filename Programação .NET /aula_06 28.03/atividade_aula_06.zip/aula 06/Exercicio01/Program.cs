﻿//1 - Escreva uma classe Aluno contendo todos os atributos de um aluno. Faça métodos para apresentar os dados.
//Faça a leitura pelo teclado dos atributos e crie um construtor para fazer o instanciamento.
using System;

namespace Exercicio01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            String nomeCompleto;
            String cpf;
            String curso;
            int matricula;
            int anoIngresso;
            DateTime dataNascimento = new DateTime();

            Console.Write("Digite o nome completo do aluno: ");
            nomeCompleto = Console.ReadLine();
            Console.Write("Digite a data de nascimento do aluno");
            dataNascimento = DateTime.Parse(Console.ReadLine());
            Console.Write("Digite o CPF do aluno: ");
            cpf = Console.ReadLine();
            Console.Write("Digite o curso do aluno: ");
            curso = Console.ReadLine();
            Console.Write("Digite a matricula  do aluno: ");
            matricula = int.Parse(Console.ReadLine());
            Console.Write("Digite o de ingresso  do aluno: ");
            anoIngresso = int.Parse(Console.ReadLine());

            Aluno a = new Aluno(nomeCompleto, cpf, curso, matricula, anoIngresso, dataNascimento);
            Console.WriteLine("\n Dados do aluno");
            a.Nome();
            a.Cpf();
            a.DataNascimento();
            a.Curso();
            a.Matricula();
            a.Anoingresso();


        }
    }
}
