﻿//1- Escreva uma classe Aluno contendo todos os atributos de um aluno. Faça métodos para apresentar os dados.
//Faça a leitura pelo teclado dos atributos e crie um construtor para fazer o instanciamento.

namespace Exercicio01
{
    class Aluno
    {
        public String nomeCompleto;
        public String cpf;
        public String curso;
        public int matricula;
        public int anoIngresso;
        public DateTime dataNascimento;

        public Aluno(string nomeCompleto, string cpf, string curso, int matricula, int anoIngresso, DateTime dataNascimento)
        {
            this.nomeCompleto = nomeCompleto;
            this.cpf = cpf;
            this.curso = curso;
            this.matricula = matricula;
            this.anoIngresso = anoIngresso;
            this.dataNascimento = dataNascimento;
        }

        public void Nome()
        {
            Console.WriteLine("O nome completo:  "+nomeCompleto);
        }
        public void Cpf()
        {
            Console.WriteLine("O cpf : " + cpf);
        }
        public void DataNascimento()
        {
            Console.WriteLine("Data de nascimento : " + dataNascimento.ToString("d"));
        }

        public void Curso()
        {
            Console.WriteLine("Curso:  " + curso);
        }
        public void Matricula()
        {
            Console.WriteLine("A matricula:  " + matricula);
        }
        public void Anoingresso()
        {
            Console.WriteLine("Ano de ingresso:  " + anoIngresso);
        }

    }
}
