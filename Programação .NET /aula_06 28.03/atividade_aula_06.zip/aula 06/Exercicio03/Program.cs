﻿//3 - Crie uma classe chamada Personagem. Defina seus atributos, mas dentre eles deve conter: Nome, posição e itens coletados, no mínimo.
//Crie construtor e faça a leitura dos atributos pelo teclado.
//Crie um método chamado “atacar” que recebe por parâmetro uma variável do tipo double que indica o dano do ataque numa escala de 0 a 10.
//O método deve apresentar uma mensagem na tela com o dano.
//Crie um método chamado “movimentar” que deve receber por parâmetro uma variável do tipo int que indica a direção que o personagem vaise mover
//(1 – frente, 2 – trás, 3 – direita e 4 – esquerda). O método deve apresentar uma mensagem na tela mostrando a direção que o personagem vai semover.

namespace Exercicio03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            String nome;
            String posicao;
            String itenColetados;
            String nivel;
            String forca;

            Console.Write("Digite o nome do personagem: ");
            nome = Console.ReadLine();
            Console.Write("Digite o posição do personagem: ");
            posicao = Console.ReadLine();
            Console.Write("Digite o itens coletados do personagem: ");
            itenColetados = Console.ReadLine();
            Console.Write("Digite o nivel do personagem: ");
            nivel = Console.ReadLine();
            Console.Write("Digite a força do personagem: ");
            forca = Console.ReadLine();

            Personagem p = new Personagem(nome, posicao, itenColetados, nivel, forca);

            double ataque;
            Console.Write("Qual o dano de ataque do personagem em  escala de 0 a 10? ");
            ataque=double.Parse(Console.ReadLine());

            int movimento;
            do
            {
                Console.Write("Para onde que movimentar o personagem ? (1 – frente, 2 – trás, 3 – direita e 4 – esquerda)");
                movimento = int.Parse(Console.ReadLine());
                if(movimento != 1 && movimento != 2 && movimento != 3 && movimento != 4)
                {
                    Console.WriteLine("opção invalida");
                }
            } while (movimento != 1 && movimento != 2 && movimento != 3 && movimento != 4);
            Console.WriteLine("\n");
            p.atacar(ataque);
            p.movimentar(movimento);

        }
    }
}
