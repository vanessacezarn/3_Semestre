﻿//3 - Crie uma classe chamada Personagem. Defina seus atributos, mas dentre eles deve conter: Nome, posição e itens coletados, no mínimo.
//Crie construtor e faça a leitura dos atributos pelo teclado.
//Crie um método chamado “atacar” que recebe por parâmetro uma variável do tipo double que indica o dano do ataque numa escala de 0 a 10.
//O método deve apresentar uma mensagem na tela com o dano.
//Crie um método chamado “movimentar” que deve receber por parâmetro uma variável do tipo int que indica a direção que o personagem vaise mover
//(1 – frente, 2 – trás, 3 – direita e 4 – esquerda). O método deve apresentar uma mensagem na tela mostrando a direção que o personagem vai semover.

namespace Exercicio03
{
    class Personagem
    {
        public String nome;
        public String posicao;
        public String itenColetados;
        public String nivel;
        public String forca;

        public Personagem(string nome, string posicao, string itenColetados, string nivel, string forca)
        {
            this.nome = nome;
            this.posicao = posicao;
            this.itenColetados = itenColetados;
            this.nivel = nivel;
            this.forca = forca;
        }
        public void atacar(double ataque)
        {
            Console.WriteLine("O personagem apresenta um dano de ataque igual a "+ataque);
        }
        public void movimentar(int dir) {
            if (dir == 1)
            {
                Console.WriteLine("Personagem está se movendo para FRENTE");
            }
            else if (dir == 2)
            {
                Console.WriteLine("Personagem está se movendo para TRAS");
            }
            else if (dir == 3)
            {
                Console.WriteLine("Personagem está se movendo para DIREITA");
            }
            else
            {
                Console.WriteLine("Personagem está se movendo para ESQUERDA");
            }
        }
    }
}
